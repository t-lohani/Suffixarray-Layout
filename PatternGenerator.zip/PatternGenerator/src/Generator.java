import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;


public class Generator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file = null;
		Scanner input = null;
		
		final String file_name = "PatternPool.txt";
		
		BufferedWriter bw = null;
		FileWriter fw = null;
		String next = null;
		
		try {
			file = new File("Data.txt");
			input = new Scanner(file);
			
			fw = new FileWriter(file_name);
			bw = new BufferedWriter(fw);
			
			int i = 0;
			int j = 0;
			int highInd;
			int lowLen = 10;
			int highLen = 100;
			
			Random random = new Random();
			
			int randLen = 0;
			int randInd = 0;
			
			while (input.hasNextLine()) {
				System.out.println(i + "\n");
				input.nextLine();
				next = input.nextLine();
				randLen = random.nextInt(highLen - lowLen) + lowLen;
				highInd = next.length()-1-randLen;
				if (highInd > 0) {
					randInd = random.nextInt(highInd);
					bw.write(next.substring(randInd, randInd+randLen));
					bw.newLine();
					j++;
				}
				i++;
			}
			
			System.out.println(j);
			
		} catch (IOException e) {
			System.out.println("Error");
		} finally {

			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

}
