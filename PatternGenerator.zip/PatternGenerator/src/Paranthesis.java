import java.util.Stack;

public class Paranthesis {

	static String[] braces(String[] values) {
	String[] out = new String[values.length];
	
	for (int q = 0; q < values.length; q++) {
		String s = values[q];
		if (isValid(s))
		out[q] = "YES";
		else
		out[q] = "NO";
	}
	return out;
}

public static boolean isValid(String s) {
	Stack<Character> stack = new Stack<Character>();
	int flag = 0;
	for (int i = 0; i < s.length(); i++) {
		if (s.charAt(i) == '{' || s.charAt(i) == '(' || s.charAt(i) == '[') {
		stack.push(s.charAt(i));
		} else {
			if (stack.isEmpty())
				return false;
			
			char temp = stack.pop();
			
			if ((s.charAt(i) == ')' && temp == '(')
			|| (s.charAt(i) == '}' && temp == '{')
			|| (s.charAt(i) == ']' && temp == '[')) {
				continue;
			} else {
				flag = 1;
				break;
			}
		}
	}
	if (stack.size() == 0 && flag == 0)
	return true;
	return false;
}

public static void main(String[] args) {
String[] s = new String[2];
s[0] = "{}[]()";
s[1] = "{[}]";

String[] out = braces(s);
for (String s1 : out)
System.out.println(s1);
}

}