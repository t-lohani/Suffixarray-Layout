import java.util.Stack;


public class Algorithm {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {2, 5, 4, 6, 8};
	    printMaxOfMin(3, arr);
	}
	
	public static int printMaxOfMin(int n, int arr[]) {
		
		Stack<Integer> stack = new Stack<>();
		
		int arrLen =  arr.length;
	    int left[] = new int[arrLen+1];  
	    int right[] = new int[arrLen+1]; 
	 
	    for (int i=0; i<arrLen; i++)
	    {
	        left[i] = -1;
	        right[i] = arrLen;
	    }
	 
	    for (int i=0; i<arrLen; i++)
	    {
	        while (!stack.empty() && arr[stack.peek()] >= arr[i])
	            stack.pop();
	 
	        if (!stack.empty())
	            left[i] = stack.peek();
	 
	        stack.push(i);
	    }
	 
	    while (!stack.empty())
	        stack.pop();
	 
	    for (int i = arrLen-1 ; i>=0 ; i-- )
	    {
	        while (!stack.empty() && arr[stack.peek()] >= arr[i])
	            stack.pop();
	 
	        if(!stack.empty())
	            right[i] = stack.peek();
	 
	        stack.push(i);
	    }
	 
	    int ans[] = new int[arrLen+1];
	    for (int i=0; i<=arrLen; i++)
	        ans[arrLen] = 0;
	 
	    for (int i=0; i<arrLen; i++)
	    {
	        int len = right[i] - left[i] - 1;
	        ans[len] = ans[len] > arr[i] ? ans[len] : arr[i];
	    }
	 
	    for (int i=arrLen-1; i>=1; i--)
	    	ans[i] = ans[i] > ans[i+1] ? ans[i] : ans[i+1];
	    
	    return ans[n];
	}

}
