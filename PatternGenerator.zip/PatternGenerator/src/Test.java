
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Test {
	public static void main(String[] args){
		String[] Str=  {"ankit IV","aayush II","ankit I","ayush II"}; 
		String[] retString= parseStringAndRoman(Str);
		for(int j=0;j<retString.length;j++){
			System.out.println(retString[j]);
		}
		
	}
	
	public static String[] parseStringAndRoman(String[] str){
		String[] s = new String[str.length];
		String[] roman = new String[str.length];
		HashMap<String, List<Integer>> map = new HashMap<String , List<Integer>>();
		List<String> strList = new ArrayList<String>();
		for(int i= 0;i<str.length;i++){
			String[] spl  =str[i].split(" ");
			int intVal = romanToInt(spl[1]);
			if(map.containsKey(spl[0])){
				List<Integer> lst = map.get(spl[0]);
				lst.add(intVal);
				map.put(spl[0], lst);
			}else{
				strList.add(spl[0]);
				List<Integer> ls = new ArrayList<Integer>();
				ls.add(intVal);
				map.put(spl[0], ls);
			}
		}
		Collections.sort(strList);
		int k= 0;
		for(int j=0;j<strList.size();j++){
			String st = strList.get(j);
			if(map.get(st).size() > 1){
				List<Integer> intList = map.get(strList.get(j));
				Collections.sort(intList);
				for(int i=0;i<intList.size();i++){
					String romVal= intToRoman(intList.get(i));
					str[k] = st + " " + romVal;
					k++;
				}
				
			}else{
				List<Integer> intList = map.get(strList.get(j));
					String romVal= intToRoman(map.get(strList.get(j)).get(0));
					str[k] = st + " " + romVal;
					k++;
			}
		}
		return str;
	}
	
	public static String intToRoman(int num) {
        if(num<1){
        	return "";
        }
  String[] roman = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
  int[] number = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
  StringBuilder str = new StringBuilder();  
  for(int i=0;i<roman.length;i++){
  	int q = num/number[i];
  	while(q>0){
  	str.append(roman[i]);
  	q--;
  	}
  	num = num%number[i];
  }
  return str.toString();

   }
	    public static int romanToInt(String s) {
	         if(s.length()<1){
	   	return 0;
	   }
	   int num=0;
	   char pre = ' ';
	   char post = ' ';
	   for(int i=0;i<s.length();i++){
	       if(i<s.length()-1){
	           post = s.charAt(i+1);
	       }else{
	           post = ' ';
	       }
	  if(s.charAt(i)=='M' && pre != 'C' ){
	  num+=1000;
	  }
	 if(s.charAt(i)=='M' && pre == 'C' ){
	  num+=900;
	  }
	if(s.charAt(i)=='D' && pre == 'C' ){
	  num+=400;
	  }
	if(s.charAt(i)=='D' && pre != 'C' ){
	  num+=500;
	  }
	if(s.charAt(i)=='C' && pre == 'X' ){
	  num+=90;
	  }
	if(s.charAt(i)=='C' && pre != 'X' && post != 'M' && post != 'D'){
	  num+=100;
	  }
	if(s.charAt(i)=='L' && pre == 'X' ){
	  num+=40;
	  }
	if(s.charAt(i)=='L' && pre != 'X' ){
	  num+=50;
	  }
	if(s.charAt(i)=='X' && pre == 'I' ){
	  num+=9;
	  }
	if(s.charAt(i)=='X' && pre != 'I'&& post != 'C' && post != 'L' ){
	  num+=10;
	  }
	if(s.charAt(i)=='V' && pre == 'I' ){
	  num+=4;
	  }
	if(s.charAt(i)=='V' && pre != 'I' ){
	  num+=5;
	  }
	if(s.charAt(i)=='I' && post != 'X' && post != 'V' ){
	  num+=1;
	  }
	pre = s.charAt(i);
	   }
	   return num;
	    }
	
}
